//   Yr  www.0ysec.com
$(document).ready(function(){
	$('.hd').slideDown(2000);
})
$(document).ready(function(){
	$('.bd').slideDown(3000);
})